﻿using System;
using System.Collections.Generic;

namespace z03
{
    class Program
    {
        static void Main(string[] args)
        {
            // Treba 30000000 umesto 1000
            List<object> niz = new List<object> (1000);
            int ukDuz = 0;

            for (int i = 0; i < niz.Capacity - 1; i++)
            {
                if (i % 3 == 0) niz.Add(null);
                else if (i % 3 == 1) niz.Add("string" + i);
                else if (i % 3 == 2) niz.Add(new object());
            }

            for (int i = 0; i < niz.Capacity - 1; i++)
            {
                try
                {
                    string curr = niz[i] as String;
                    if (curr != null)
                        ukDuz += curr.Length;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            Console.WriteLine("Ukupna duzina stringova: " + ukDuz);
        }
    }
}
