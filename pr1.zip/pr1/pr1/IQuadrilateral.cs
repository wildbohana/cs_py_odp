﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pr1
{
    interface IQuadrilateral
    {
        // Properties
        int Width { get; set; }
        int Length { get; set; }

        // Function - obim
        double CalculatePerimeter(int a, int b);
        // Function - površina
        double CalculateArea(int a, int b);

        // Method
        string ShowInfo();
    }
}
