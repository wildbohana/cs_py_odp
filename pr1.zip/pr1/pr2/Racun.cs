﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pr2
{
    abstract class Racun
    {
        public abstract void uplata(double suma);
        public abstract void isplata(double suma);
    }
}
